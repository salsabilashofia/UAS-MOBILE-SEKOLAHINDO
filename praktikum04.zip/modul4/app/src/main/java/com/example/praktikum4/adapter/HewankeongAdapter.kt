package com.example.praktikum4.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.praktikum4.R
import com.example.praktikum4.model.HewanKeong

class HewankeongAdapter(
    private val context: Context,
    private val keongArrayList: ArrayList<HewanKeong>

):RecyclerView.Adapter<HewankeongAdapter.ItemViewHolder>() {
    class ItemViewHolder(val view: View):RecyclerView.ViewHolder(view){
        val namaHewanKeongtextView: TextView = view.findViewById(R.id.namahewankeong)
        val gambarhewanKeong: ImageView = view.findViewById(R.id.gambarkeong)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val hewankeongAdapterlayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_keong,parent,false)
        return ItemViewHolder(hewankeongAdapterlayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = keongArrayList[position]
        holder.namaHewanKeongtextView.text = context?.resources.getString(item.namakeong)
        holder.gambarhewanKeong.setImageResource(item.gambarkeong)
        holder.view.setOnClickListener {
            Toast.makeText(context, "Data dipilih", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount(): Int {
        return keongArrayList.size
    }

}