package com.example.praktikum4.ui.siputairtawar

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.praktikum4.R
import com.example.praktikum4.model.SiputAirTawar

class SiputAirTawarViewModel : ViewModel() {
    var siputairtawarMutableLiveData: MutableLiveData<ArrayList<SiputAirTawar>?> = MutableLiveData()
    var siputairtawarArrayList: ArrayList<SiputAirTawar>? = null

    fun init(){
        siputairtawarlist()
        siputairtawarMutableLiveData.value = siputairtawarArrayList
    }

    fun siputairtawarlist(){
        var siputairtawar = SiputAirTawar(R.string.siputairtawar1,R.drawable.siputlumpurselandia)
        siputairtawarArrayList = ArrayList()
        siputairtawarArrayList!!.add(siputairtawar)
        siputairtawar = SiputAirTawar(R.string.siputairtawar2,R.drawable.keongmurbai)
        siputairtawarArrayList!!.add(siputairtawar)
    }
    init {
        init()
    }

}
