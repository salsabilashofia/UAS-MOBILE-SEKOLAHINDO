package com.example.praktikum4.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class HewanKeong (
    @StringRes val namakeong : Int,
    @DrawableRes val gambarkeong : Int,
)