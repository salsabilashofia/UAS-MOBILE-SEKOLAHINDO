package com.example.praktikum4.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.praktikum4.R
import com.example.praktikum4.model.SiputAirTawar

class SiputairtawarAdapter(
    private val context: Context,
    private val siputairtawarArrayList: ArrayList<SiputAirTawar>

):RecyclerView.Adapter<SiputairtawarAdapter.ItemViewHolder>() {
    class ItemViewHolder(val view: View):RecyclerView.ViewHolder(view){
        val namaHewanSiputAirTawartextView: TextView = view.findViewById(R.id.namasiputairtawar)
        val gambarSiputAirTawar: ImageView = view.findViewById(R.id.gambarsiputairtawar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val SiputairtawarAdapterlayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_siputairlaut,parent,false)
        return ItemViewHolder(SiputairtawarAdapterlayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = siputairtawarArrayList[position]
        holder.namaHewanSiputAirTawartextView.text = context?.resources.getString(item.namasiputairtawar)
        holder.gambarSiputAirTawar.setImageResource(item.gambarsiputairtawar)
        holder.view.setOnClickListener {
            Toast.makeText(context, "Data dipilih", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount(): Int {
        return siputairtawarArrayList.size
    }

}