package com.example.praktikum4.ui.siputlaut

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.praktikum4.R
import com.example.praktikum4.model.SiputLaut

class SiputLautViewModel : ViewModel() {
    var siputlautMutableLiveData: MutableLiveData<ArrayList<SiputLaut>?> = MutableLiveData()
    var siputlautArrayList: ArrayList<SiputLaut>? = null

    fun init(){
        siputlautlist()
        siputlautMutableLiveData.value = siputlautArrayList
    }

    fun siputlautlist(){
        var siputlaut = SiputLaut(R.string.siputlaut1,R.drawable.conusmagus)
        siputlautArrayList = ArrayList()
        siputlautArrayList!!.add(siputlaut)
        siputlaut = SiputLaut(R.string.siputlaut2,R.drawable.limpet)
        siputlautArrayList!!.add(siputlaut)
        siputlaut = SiputLaut(R.string.siputlaut3,R.drawable.whelk)
        siputlautArrayList!!.add(siputlaut)
    }
    init {
        init()
    }

}
