package com.example.praktikum4.ui.aquascape

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.praktikum4.R
import com.example.praktikum4.model.HewanKeong

class KeongViewModel : ViewModel() {
    var keongMutableLiveData: MutableLiveData<ArrayList<HewanKeong>?> = MutableLiveData()
    var keongArrayList: ArrayList<HewanKeong>? = null

    fun init(){
        keonglist()
        keongMutableLiveData.value = keongArrayList
    }

    fun keonglist(){
        var hkeong = HewanKeong(R.string.keong1,R.drawable.keongapel)
        keongArrayList = ArrayList()
        keongArrayList!!.add(hkeong)
        hkeong = HewanKeong(R.string.keong2,R.drawable.keongassassin)
        keongArrayList!!.add(hkeong)
        hkeong = HewanKeong(R.string.keong3,R.drawable.keongbawang)
        keongArrayList!!.add(hkeong)
        hkeong = HewanKeong(R.string.keong4,R.drawable.keongramshorn)
        keongArrayList!!.add(hkeong)
        hkeong = HewanKeong(R.string.keong5,R.drawable.keongsulawesi)
        keongArrayList!!.add(hkeong)
    }
    init {
        init()
    }

}
