package com.example.praktikum4.ui.siputlaut

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.praktikum4.R
import com.example.praktikum4.adapter.SiputlautAdapter
import com.example.praktikum4.databinding.FragmentSiputlautBinding
import com.example.praktikum4.model.SiputLaut

class SiputLautFragment : Fragment(R.layout.fragment_siputlaut) {
    private lateinit var recyclerView: RecyclerView
    private var _binding: FragmentSiputlautBinding? = null
    private val binding get() = _binding!!
    var recyclerViewsiputlautAdapter: SiputlautAdapter? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val SiputLautViewModel =
            ViewModelProvider(this).get(SiputLautViewModel::class.java)
        SiputLautViewModel?.siputlautMutableLiveData.observe(viewLifecycleOwner,siputlautListUpdateObserver)
        _binding = FragmentSiputlautBinding.inflate(inflater, container, false)
        val root: View = binding.root
        recyclerView = _binding!!.recylerViewSiputlaut
        return root

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    var siputlautListUpdateObserver : Observer<ArrayList<SiputLaut>?> =
        Observer<ArrayList<SiputLaut>?>{ siputlautArrayList ->
            recyclerViewsiputlautAdapter = SiputlautAdapter(requireContext(),siputlautArrayList)
            recyclerView!!.layoutManager = LinearLayoutManager(context)
            recyclerView!!.adapter = recyclerViewsiputlautAdapter
        }
}