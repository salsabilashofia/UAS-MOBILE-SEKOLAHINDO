package com.example.praktikum4.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class SiputAirTawar (
    @StringRes val namasiputairtawar : Int,
    @DrawableRes val gambarsiputairtawar : Int,
)