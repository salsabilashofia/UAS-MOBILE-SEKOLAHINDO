package com.example.praktikum4.ui.aquascape

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.praktikum4.R
import com.example.praktikum4.adapter.HewankeongAdapter
import com.example.praktikum4.model.HewanKeong
import com.example.praktikum4.databinding.FragmentHewankeongBinding

class KeongFragment : Fragment(R.layout.fragment_hewankeong) {
    private lateinit var recyclerView: RecyclerView
    private var _binding: FragmentHewankeongBinding? = null
    private val binding get() = _binding!!
    var recyclerViewkeongAdapter: HewankeongAdapter? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val keongViewModel =
            ViewModelProvider(this).get(KeongViewModel::class.java)
        keongViewModel?.keongMutableLiveData.observe(viewLifecycleOwner,keongListUpdateObserver)
        _binding = FragmentHewankeongBinding.inflate(inflater, container, false)
        val root: View = binding.root
        recyclerView = _binding!!.recylerViewKeong
        return root

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    var keongListUpdateObserver : Observer<ArrayList<HewanKeong>?> =
        Observer<ArrayList<HewanKeong>?>{ keongArrayList ->
            recyclerViewkeongAdapter = HewankeongAdapter(requireContext(),keongArrayList)
            recyclerView!!.layoutManager = LinearLayoutManager(context)
            recyclerView!!.adapter = recyclerViewkeongAdapter
        }
}