package com.example.praktikum4.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class SiputLaut (
    @StringRes val namasiputlaut : Int,
    @DrawableRes val gambarsiputlaut : Int,
)