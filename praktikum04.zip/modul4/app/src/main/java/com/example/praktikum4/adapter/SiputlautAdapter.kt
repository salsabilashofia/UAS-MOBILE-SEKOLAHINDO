package com.example.praktikum4.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.praktikum4.R
import com.example.praktikum4.model.SiputLaut

class SiputlautAdapter(
    private val context: Context,
    private val siputlautArrayList: ArrayList<SiputLaut>

):RecyclerView.Adapter<SiputlautAdapter.ItemViewHolder>() {
    class ItemViewHolder(val view: View):RecyclerView.ViewHolder(view){
        val namaHewanSiputLauttextView: TextView = view.findViewById(R.id.namasiputlaut)
        val gambarSiputLaut: ImageView = view.findViewById(R.id.gambarsiputlaut)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val SiputlautAdapterlayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_siputlaut,parent,false)
        return ItemViewHolder(SiputlautAdapterlayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = siputlautArrayList[position]
        holder.namaHewanSiputLauttextView.text = context?.resources.getString(item.namasiputlaut)
        holder.gambarSiputLaut.setImageResource(item.gambarsiputlaut)
        holder.view.setOnClickListener {
            Toast.makeText(context, "Data dipilih", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount(): Int {
        return siputlautArrayList.size
    }

}